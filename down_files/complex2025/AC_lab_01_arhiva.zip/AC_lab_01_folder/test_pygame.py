import pygame.examples.stars

if __name__ == '__main__':
    pygame.examples.stars.main()