import ComplexPygame as C
import Color
import math
def ExpSerie(z):
    s = 0
    p = 1
    for n in range(1, 100):
        s += p
        p *= z / n
    return s
def ExpReIm(z):
    return C.fromRhoTheta(math.exp(z.real), z.imag)

def Analitic():
    # comparam vizual functiile
    # ExpReIm() si ExpSerie()

    def arataMod(h, k, z):
        kol = int(100 * z.real)
        C.setPixelHK(h, k, Color.Index(kol))

    def arataArg(h, k, z):
        kol = int(512 * (1 + C.theta(z) / math.pi))
        C.setPixelHK(h, k, Color.Index(kol))

    lat = 2 * math.pi
    C.setXminXmaxYminYmax(-lat, lat, -lat, lat)
    C.setAxis()
    dim2 = C.dim // 2

    for h in range(dim2):
        for k in range(dim2):
            z = C.getZ(2 * h, 2 * k)
            vExact = ExpReIm(z)
            vAprox = ExpSerie(z)

            arataArg(h, k, vExact)
            arataMod(h, k + dim2, vExact)

            arataArg(h + dim2, k, vAprox)
            arataMod(h + dim2, k + dim2, vAprox)
        if C.mustClose():
            return
    C.setAxis()



if __name__ == '__main__':
    C.initPygame()
    C.run(Analitic)
   