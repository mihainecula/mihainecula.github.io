import ComplexPygame as C
import Color
import math


def Z_orderBin():
    def incrementare(regBin):
        #  trecem pe 01000111
        #  in        01001000
        #  prin adunarea cu 1
        avemTransport = True
        k = 0
        while k < len(regBin) and avemTransport:
            if regBin[k] == 1:
                regBin[k] = 0
            else:
                regBin[k] = 1
                avemTransport = False
            k += 1
        return not avemTransport

    def traseaza(li):
        for n in range(1, len(li)):
            C.drawLine(li[n - 1], li[n], Color.Index(600 + n // 5))
        C.refreshScreen()

    C.setXminXmaxYminYmax(-0.1, 1.1, 1.1, -0.1)
    k = 6
    k2 = 2 * k
    reg = [0] * k2
    fig = [0]
    while incrementare(reg):
        #  aflam x si y
        y = 0
        p = 1
        for h in range(k2 - 1, 0, -2):
            p *= 2
            y += reg[h] / p
        x = 0
        p = 1
        for h in range(k2 - 2, -1, -2):
            p *= 2
            x += reg[h] / p
        fig.append(complex(x, y))
    traseaza(fig)


####################################################

def Z_order():
    c0 = (1 + 1j) / 2
    c1 = (1 + 1j) / 4
    c2 = (1 + 3j) / 4
    c3 = (3 + 3j) / 4
    c4 = (3 + 1j) / 4

    #  sk(z)=c0+0.5*(z-c0) +(ck-c0)=ck+0.5*(z-c0)
    def s1(z):
        return c1 + 0.5 * (z - c0)

    def s2(z):
        return c2 + 0.5 * (z - c0)

    def s3(z):
        return c3 + 0.5 * (z - c0)

    def s4(z):
        return c4 + 0.5 * (z - c0)

    def transforma(li):

        rez = []
        for z in li:
            rez.append(s2(z))
        for z in li:
            rez.append(s3(z))
        for z in li:
            rez.append(s1(z))
        for z in li:
            rez.append(s4(z))
        return rez

    def traseaza(li):
        C.fillScreen()
        #  trasam chenarul
        C.drawNgon([0, 1, 1 + 1j, 1j], Color.Index(500))
        #  desenam curba curenta
        for n in range(1, len(li)):
            C.drawLine(li[n - 1], li[n], Color.Index(n // 5))

    C.setXminXmaxYminYmax(-0.1, 1.1, -0.1, 1.1)
    fig = [c0]
    for k in range(6):
        fig = transforma(fig)
        traseaza(fig)
        if C.mustClose(): return
        C.wait(100)


####################################################

def Hilbert():
    c0 = (1 + 1j) / 2
    c1 = (1 + 1j) / 4
    c2 = (1 + 3j) / 4
    c3 = (3 + 3j) / 4
    c4 = (3 + 1j) / 4

    def s1(z):
        return c1 + 0.5j * (z - c0).conjugate()

    def s2(z):
        return c2 + 0.5 * (z - c0)

    def s3(z):
        return c3 + 0.5 * (z - c0)

    def s4(z):
        return c4 - 0.5j * (z - c0).conjugate()

    def transforma(li):

        rez = []
        for z in li:
            rez.append(s1(z))
        for z in li:
            rez.append(s2(z))
        for z in li:
            rez.append(s3(z))
        for z in li:
            rez.append(s4(z))
        return rez

    def traseaza(li):
        C.fillScreen()
        #  trasam chenarul
        C.drawNgon([0, 1, 1 + 1j, 1j], Color.Index(500))
        #  desenam curba curenta
        for n in range(1, len(li)):
            C.drawLine(li[n - 1], li[n], Color.Index(n // 500))

    C.setXminXmaxYminYmax(-0.1, 1.1, -0.1, 1.1)
    fig = [c0]
    for k in range(9):
        fig = transforma(fig)
        traseaza(fig)
        if C.mustClose(): return
        C.wait(100)

####################################################

def HilbertMotiveIterate():
    def transforma(li):
        z1 = li[0]
        rez = [z1]
        for k in range(1, len(li), 2):
            z0 = li[k]
            z4 = li[k + 1]
            z3 = 2 * z0 - z1
            z2 = 2 * z0 - z4
            rez.append((z1 + z0) / 2)
            rez.append((z1 + z2) / 2)
            rez.append((z0 + z2) / 2)
            rez.append(z0)
            rez.append((z0 + z3) / 2)
            rez.append((z3 + z4) / 2)
            rez.append((z0 + z4) / 2)
            rez.append(z4)
            z1 = z4
        return rez

    def traseazaPatrate(li):
        C.fillScreen()
        z1 = li[0]
        for k in range(1, len(li), 2):
            z0 = li[k]
            z4 = li[k + 1]
            z3 = 2 * z0 - z1
            z2 = 2 * z0 - z4
            C.drawNgon([z1, z2, z3, z4], Color.Black)
            C.drawLine(z1, z0, Color.Red)
            C.drawLine(z0, z4, Color.Blue)
            z1 = z4
        C.refreshScreen()

    # def traseazaLinii(li):
    #     C.fillScreen()
    #     kol = 0
    #     z1 = li[0]
    #     for k in range(1, len(li), 2):
    #         z0 = li[k]
    #         z4 = li[k + 1]
    #         col = Color.Index(kol // 1000)
    #         kol += 1
    #         C.drawLine(z1, z0, col)
    #         C.drawLine(z0, z4, col)
    #         z1 = z4
    #     C.refreshScreen()

    C.setXminXmaxYminYmax(-0.25, 1.25, -0.25, 1.25)
    C.fillScreen()
    fig = [0, 0.5 + 0.5j, 1]
    traseazaPatrate(fig)
    for k in range(3):
        fig = transforma(fig)
        traseazaPatrate(fig)
        # traseazaLinii(fig)
        C.wait(500)

####################################################
if __name__ == '__main__':
    C.initPygame()
    # C.run(Z_orderBin)
    # C.run(Z_order)
    C.run(Hilbert)
    # C.run(HilbertMotiveIterate)
