import ComplexPygame
import ComplexPygame as C
import Color
import math
import cmath


def Peano0():
    c1 = (1 + 1j) / 6
    c2 = (1 + 3j) / 6
    c3 = (1 + 5j) / 6
    c4 = (3 + 5j) / 6
    c0 = (3 + 3j) / 6
    c5 = (3 + 1j) / 6
    c6 = (5 + 1j) / 6
    c7 = (5 + 3j) / 6
    c8 = (5 + 5j) / 6

    def s0(z):
        return c0 + (z - c0) / 3

    def s1(z):
        return c1 + (z - c0) / 3

    def s2(z):
        return c2 + (z - c0) / 3

    def s3(z):
        return c3 + (z - c0) / 3

    def s4(z):
        return c4 + (z - c0) / 3

    def s5(z):
        return c5 + (z - c0) / 3

    def s6(z):
        return c6 + (z - c0) / 3

    def s7(z):
        return c7 + (z - c0) / 3

    def s8(z):
        return c8 + (z - c0) / 3

    def transforma(li):
        rez = []
        for z in li:  rez.append(s1(z))
        for z in li:  rez.append(s2(z))
        for z in li:  rez.append(s3(z))
        for z in li:  rez.append(s4(z))
        for z in li:  rez.append(s0(z))
        for z in li:  rez.append(s5(z))
        for z in li:  rez.append(s6(z))
        for z in li:  rez.append(s7(z))
        for z in li:  rez.append(s8(z))
        return rez

    def traseaza(li):
        C.fillScreen()
        # trasam chenarul
        C.drawNgon([0, 1, 1 + 1j, 1j], Color.Black)
        for n in range(1, len(li)):
            col = Color.Red if n % 9 == 0 else Color.Blue
            C.drawLine(li[n - 1], li[n], col)

    C.setXminXmaxYminYmax(-0.1, 1.1, -0.1, 1.1)
    fig = [c0]
    for k in range(2):
        fig = transforma(fig)
        traseaza(fig)
        if C.mustClose(): return


#################################################################################



if __name__ == '__main__':
    C.initPygame()
    C.run(Peano0)

