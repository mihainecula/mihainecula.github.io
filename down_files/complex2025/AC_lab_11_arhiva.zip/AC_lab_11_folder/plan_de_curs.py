import ComplexPygame as C
import Color
import math

def Z_orderPeBiti():
    k = 6  # atentie: 0 < k < 15
    nrPuncte = 1 << (2 * k)
    lat = 1 << k
    C.setXminXmaxYminYmax(-1, lat, lat, -1)
    zvechi = 0
    for n in range(nrPuncte):
        x = 0
        y = 0
        nn = n
        for h in range(k):
            x |= (nn & 1) << h
            nn >>= 1
            y |= (nn & 1) << h
            nn >>= 1
        znou = complex(x, y)
        C.drawLine(znou, zvechi, Color.Index(n // 10))
        zvechi = znou
        if C.mustClose(): return


##############################################################

def HilbertRecursiv():
    za = 0
    zb = 0

    #   z0 = coltul curent
    #   d1 = prima deplasare
    #   d2 = a doua deplasare
    #  -d1 = a treia deplasare
    def genereaza(z0, d1, d2, niv):
        nonlocal za, zb
        if niv <= 0:
            zb = z0 + (d1 + d2) / 2  # zb = centrul patratului curent
            C.drawLine(za, zb, Color.Red)
            za = zb  # za = centrul vechi
        else:
            niv -= 1
            d1 *= 0.5
            d2 *= 0.5
            genereaza(z0, d2, d1, niv)
            genereaza(z0 + d1, d1, d2, niv)
            genereaza(z0 + d1 + d2, d1, d2, niv)
            genereaza(z0 + d1 + d2 + d2, -d2, -d1, niv)

    C.setXminXmaxYminYmax(-0.1, 1.1, -0.1, 1.1)
    z0 = 0
    d1 = 1j
    d2 = 1
    #   traseu prin patratul initial:
    #   z0 = coltul din stanga jos
    #   z0+d1 = coltul din stanga sus
    #   z0+d1+d2 = coltul din dreapta sus
    #   z0+d1+d2–d1 = z0+d2 = coltul din dreapta jos
    nrEtape = 5
    za = z0
    genereaza(z0, d1, d2, nrEtape)
    C.drawLine(za, z0 + d2, Color.Red)
    C.refreshScreen()


if __name__ == '__main__':
    C.initPygame()

    #C.run(HilbertRecursiv)
    C.run(Z_orderPeBiti)
