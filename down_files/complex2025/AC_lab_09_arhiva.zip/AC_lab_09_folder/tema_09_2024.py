import ComplexPygame as C
import Color
import math


def PseudoSpiralaLuiArhimede():
    nrPuncte = 1000
    alfa = math.pi
    omega = C.fromRhoTheta(1, alfa / nrPuncte)

    def traseazaArc(q, delta):
        for k in range(nrPuncte):
            delta *= omega
            C.setPixel(q + delta, Color.Red)
        versor = delta / C.rho(delta)
        q -= versor
        delta += versor
        C.drawLine(q, q + delta, Color.Black)
        return q, delta

    lat = 20
    C.setXminXmaxYminYmax(-lat, lat, -lat, lat)
    q = 0
    delta = 1j
    for k in range(20):
        q, delta = traseazaArc(q, delta)
    C.refreshScreen()



##############################################################

if __name__ == '__main__':
    C.initPygame()

    C.run(PseudoSpiralaLuiArhimede)
