import ComplexPygame as C
import Color
import math

def InsulaLuiVonKoch():
    theta = math.pi / 6
    ro = 0.5 / math.cos(theta)
    w = C.fromRhoTheta(ro, theta)
    Lambda = 1 / 3.0

    def transforma(li):
        rez = [li[0]]
        for k in range(1, len(li)):
            z1 = li[k - 1]
            z2 = li[k]
            delta = z2 - z1
            # //Segmentul z1_z2 este inlocuit cu
            # //z1_zA, zA_zB, zB_zC si zC_z2, unde
            # //zA=z1 + lambda* (z2 - z1)
            # //zB=z1 + w * (z2 - z1))
            # //zC=z1 + (1-lambda) * (z2 - z1).
            rez.append(z1 + Lambda * delta)
            rez.append(z1 + w * delta)
            rez.append(z2 - Lambda * delta)
            rez.append(z2)
        return rez

    def traseaza(li):
        for k in range(1, len(li)):
            C.drawLine(li[k - 1], li[k], Color.Index(k // 500))
        return

    C.setXminXmaxYminYmax(-1, 1, -1, 1)

    fig0 = [C.fromRhoTheta(1, -2 * k * math.pi / 3) for k in range(4)]
    a, b, c = (-1 - 1j) / 2, 1j, 1
    fig0 = [a, b, c, a]
    fig = fig0
    for k in range(9):
        C.fillScreen()
        fig = transforma(fig)
        traseaza(fig)
        C.refreshScreen()
        C.wait(100)
        if C.mustClose(): return
    C.drawNgon(fig0, Color.Magenta)

##################################################################


if __name__ == '__main__':
    C.initPygame()
    C.run(InsulaLuiVonKoch)
