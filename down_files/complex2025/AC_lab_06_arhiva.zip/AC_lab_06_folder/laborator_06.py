import ComplexPygame as C
import Color
import math


###################################################################
def Integrala_01():
    def gamma(t):
        r0 = 2
        omega0 = 5
        q0 = 3j
        return q0 + C.fromRhoTheta(r0 * math.sin(omega0 * t), t)

    def f(z):
        return z * z / 3

    r = 12
    C.setXminXmaxYminYmax(-r, r, -r, r)
    C.fillScreen(Color.Navy)
    C.setAxis(Color.White)
    a = 0
    b = 2 * math.pi
    # calculam suma Riemann-Stieltjes
    N = 10000
    delta = (b - a) / N
    suma = 0
    z0 = gamma(a)
    for k in range(N):
        col = Color.Index(300 + k // 5)
        z1 = gamma(a + delta * k)
        suma += f(z1) * (z1 - z0)
        C.drawLine(0, suma, col)
        C.setPixel(z1, col)
        z0 = z1
        if C.mustClose():
            return

###################################################################
def Integrala_02():
    def gamma(t):
        r0 = 2
        omega0 = 5
        q0 = 3j
        return q0 + C.fromRhoTheta(r0 * math.sin(omega0 * t), t)

    def f(z):
        return z * z / 3

    r = 12
    C.setXminXmaxYminYmax(-r, r, -r, r)
    C.fillScreen(Color.Navy)
    C.setAxis(Color.White)

    a = 0
    b = 2 * math.pi
    # calculam suma Riemann-Stieltjes
    N = 10000
    delta = (b - a) / N
    suma0 = suma1 = 0
    z0 = gamma(a)
    for k in range(N):
        col = Color.Index(300 + k // 5)
        z1 = gamma(a + delta * k)
        suma1 += f(z1) * (z1 - z0)
        C.drawLine(0, suma0, Color.Navy)
        C.drawLine(0, suma1, col)
        C.setPixel(z0, col)
        C.setPixel(z1, col)
        z0 = z1
        suma0 = suma1
        if C.mustClose():
            return

###################################################################
def Integrala_03():
    def gamma(t):
        r0 = 2
        omega0 = 5
        q0 = 3j
        return q0 + C.fromRhoTheta(r0 * math.sin(omega0 * t), t)

    def f(z):
        x = z.real
        y = z.imag
        return complex(x * x, y * y + x)

    r = 12
    C.setXminXmaxYminYmax(-r, r, -r, r)
    C.fillScreen(Color.Navy)
    C.setAxis(Color.White)

    a = 0
    b = 2 * math.pi
    # calculam suma Riemann-Stieltjes
    N = 10000
    delta = (b - a) / N
    suma0 = suma1 = 0
    z0 = gamma(a)
    for k in range(N):
        col = Color.Index(300 + k // 5)
        z1 = gamma(a + delta * k)
        suma1 += f(z1) * (z1 - z0)
        C.drawLine(0, suma0, Color.Navy)
        C.drawLine(0, suma1, col)
        C.setPixel(z0, col)
        C.setPixel(z1, col)
        z0 = z1
        suma0 = suma1
        if C.mustClose():
            return

###################################################################
if __name__ == '__main__':
    C.initPygame()
    # C.run(Integrala_01)
    # C.run(Integrala_02)
    C.run(Integrala_03)

