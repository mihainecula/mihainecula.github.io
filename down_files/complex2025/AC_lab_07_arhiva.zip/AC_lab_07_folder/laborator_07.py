import ComplexPygame as C
import Color
import math


def FormulaLuiCauchy():
    unuPe2iPi = 1.0 / (2j * math.pi)

    ro = 2.0
    lat = ro + 0.1

    def gamma(t):
        return C.fromRhoTheta(ro, t)

    def f(z):
        return z * z * z + 1 / (z - 10)
        # return z * z * z + 1 / (z - 1)

    def arataMod(h, k, z):
        kol = int(100 * z.real)
        C.setPixelHK(h, k, Color.Index(kol))

    def arataArg(h, k, z):
        kol = int(512 * (1 + C.theta(z) / math.pi))
        C.setPixelHK(h, k, Color.Index(kol))

    def formCauchy(zstar):
        # calculam suma Riemann-Stieltjes
        # pentru h(z)=f(z)/(z-zstar)
        a = 0
        b = 2 * math.pi
        suma = 0
        z0 = gamma(a)
        t = a
        while t <= b:
            z1 = gamma(t)
            suma += f(z1) * (z1 - z0) / (z1 - zstar)
            z0 = z1
            t += 0.01
        return unuPe2iPi * suma

    C.setXminXmaxYminYmax(-lat, lat, -lat, lat)
    ScreenColor = Color.Index(0)
    C.fillScreen(ScreenColor)
    C.setAxis()
    dim2 = C.dim // 2

    for h in range(dim2):
        for k in range(dim2):
            z = C.getZ(2 * h, 2 * k)
            if C.rho(z) >= ro:
                continue
            fExact = f(z)
            fAprox = formCauchy(z)

            arataArg(h, k, fExact)
            arataMod(h, k + dim2, fExact)

            arataArg(h + dim2, k, fAprox)
            arataMod(h + dim2, k + dim2, fAprox)
        if C.mustClose():
            return
    C.setAxis()


###################################################################
if __name__ == '__main__':
    C.initPygame()
    C.run(FormulaLuiCauchy)
