import ComplexPygame as C
import Color
import math

def TransBar():
    class Triunghi:
        def __init__(self, a, b, c):
            self.zA, self.zB, self.zC = a, b, c

        def show(self):
            C.drawLine(self.zA, self.zB, Color.Red)
            C.drawLine(self.zB, self.zC, Color.Green)
            C.drawLine(self.zC, self.zA, Color.Blue)

        @property
        def aria(self):
            return ((self.zB - self.zA) * (self.zC - self.zA).conjugate()).imag / 2

    def T(S, D, z):
        # Sursa, Destinatie, zetul curent
        sigmaBC = Triunghi(z, S.zB, S.zC).aria
        sigmaCA = Triunghi(z, S.zC, S.zA).aria
        sigmaAB = Triunghi(z, S.zA, S.zB).aria
        return (sigmaBC * D.zA + sigmaCA * D.zB + sigmaAB * D.zC) / (sigmaBC + sigmaCA + sigmaAB)

    C.setXminXmaxYminYmax(0, 10, 0, 10)

    # triunghiul Sursa:
    q0 = 2 + 2j
    r0 = 1
    a, b, c = (q0 + C.fromRhoTheta(r0, (4 * k + 3) * math.pi / 6) for k in range(3))
    S = Triunghi(a, b, c)
    # figura sursa:
    N = 100
    delta = 2 * math.pi / N
    fig = [q0 + C.fromRhoTheta(r0 / 2, k * delta) for k in range(N)]
    t = 0
    while t < 100:
        C.fillScreen()

        C.fillNgon(fig, Color.Cyan)
        C.drawNgon(fig, Color.Black)
        S.show()

        # triunghiul destinatie
        D = Triunghi(5 + 8j + C.fromRhoTheta(2, t), 3 + 3j, 9 + 3j)

        # figura transformata:
        figTrans=[T(S, D, z) for z in fig]
        C.fillNgon(figTrans, Color.Cyan)
        C.drawNgon(figTrans, Color.Black)
        D.show()

        if C.mustClose():
            return
        t += 0.001

if __name__ == '__main__':
    C.initPygame()
    C.run(TransBar)
