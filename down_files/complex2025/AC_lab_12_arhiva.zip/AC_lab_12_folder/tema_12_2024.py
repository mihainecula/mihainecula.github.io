import ComplexPygame as C
import Color
import math

def Newton3():
    eps0 = C.fromRhoTheta(1.0, 0.0 * math.pi / 3.0)
    eps1 = C.fromRhoTheta(1.0, 2.0 * math.pi / 3.0)
    eps2 = C.fromRhoTheta(1.0, 4.0 * math.pi / 3.0)

    def f(z):
        if z == 0:
            return 1.0e100
        else:
            return (2 * z * z * z + 1) / (3 * z * z)

    C.setXminXmaxYminYmax(-1.5, 1.5, -1.5, 1.5)
    nrIter = 300
    for coloana in C.screenColumns():
        for zeta in coloana:
            col = Color.Black
            z = zeta
            for _ in range(nrIter):
                if C.rho(z - eps0) < 0.1:
                    col = Color.Darkblue
                    break
                if C.rho(z - eps1) < 0.1:
                    col = Color.Yellow
                    break
                if C.rho(z - eps2) < 0.1:
                    col = Color.Fuchsia
                    break
                z = f(z)
            C.setPixel(zeta, col)
        if C.mustClose(): return
    C.setAxis(Color.White)
    C.refreshScreen()



####################################################

if __name__ == '__main__':
    C.initPygame()
    C.run(Newton3)

